package SHINHAN_PORTAL.REPORT_SIMO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportSimoApplicationTests {

	@Test
	void contextLoads() {
	}

}
