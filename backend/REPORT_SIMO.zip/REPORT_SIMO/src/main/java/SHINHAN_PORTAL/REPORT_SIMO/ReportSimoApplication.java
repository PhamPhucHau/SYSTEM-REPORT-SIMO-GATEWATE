package SHINHAN_PORTAL.REPORT_SIMO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReportSimoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReportSimoApplication.class, args);
	}

}
